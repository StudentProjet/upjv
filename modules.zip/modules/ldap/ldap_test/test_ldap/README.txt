
Notes on LDAP Implementations for testing.


http://www-01.ibm.com/support/docview.wss?uid=swg21240892
https://cwiki.apache.org/GMOxDOC21/ldap-sample-app-ldap-sample-application.html
http://trac-hacks.org/wiki/LdapPluginTests
http://en.wikipedia.org/wiki/Hogwarts
http://harrypotter.wikia.com/wiki/Hogwarts_School_of_Witchcraft_and_Wizardry
